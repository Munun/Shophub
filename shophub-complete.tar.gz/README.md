# 🛍️ ShopHub - Full-Stack E-Commerce Platform

A modern, production-ready e-commerce platform built with React, Node.js, PostgreSQL, and Stripe.

## 🚀 Quick Start

### Prerequisites
- Node.js v20+
- PostgreSQL installed and running
- Stripe account (for payment processing)

### Backend Setup (5 minutes)

1. **Navigate to backend:**
   ```bash
   cd backend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Create database:**
   ```bash
   createdb shophub
   psql shophub < schema.sql
   ```

4. **Configure environment variables:**
   ```bash
   cp .env.example .env
   nano .env
   ```
   
   Update these values:
   - `DB_USER` - Your PostgreSQL username (usually your Mac username)
   - `STRIPE_SECRET_KEY` - Get from https://dashboard.stripe.com/test/apikeys
   - `STRIPE_PUBLISHABLE_KEY` - Get from https://dashboard.stripe.com/test/apikeys

5. **Start backend server:**
   ```bash
   npm run dev
   ```
   Server runs on http://localhost:5001

### Frontend Setup (3 minutes)

1. **Navigate to frontend:**
   ```bash
   cd frontend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Start dev server:**
   ```bash
   npm run dev
   ```
   App runs on http://localhost:5173

## ✨ Features

- 🛒 Shopping cart with persistent storage
- 💳 Stripe payment integration
- 🔐 JWT authentication
- 📱 Fully responsive design
- 🎨 Modern UI with Tailwind CSS
- ⚡ Fast and smooth animations
- 🔍 Product search and filtering
- ⭐ Product ratings and reviews

## 🧪 Test the App

1. **Browse products** - Visit http://localhost:5173
2. **Create account** - Click "Sign Up"
3. **Add to cart** - Click any product
4. **Checkout** - Use test card: `4242 4242 4242 4242`

## 📦 Tech Stack

**Frontend:**
- React 18
- Vite
- Tailwind CSS
- Zustand (state management)
- React Router
- Axios

**Backend:**
- Node.js + Express
- PostgreSQL
- Stripe API
- JWT authentication
- bcrypt

## 🎯 For Interviews

**Be ready to explain:**
- How JWT authentication works
- Stripe payment flow
- State management with Zustand
- RESTful API design
- Database schema design

## 📝 Environment Variables

### Backend (.env)
```
DB_HOST=localhost
DB_PORT=5432
DB_NAME=shophub
DB_USER=your_username
DB_PASSWORD=

JWT_SECRET=your_secret_key_here
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...

PORT=5001
NODE_ENV=development
```

## 🚀 Deployment

**Frontend:** Deploy to Vercel
**Backend:** Deploy to Render or Railway
**Database:** Use Render PostgreSQL or Supabase

## 📸 Screenshots

Add screenshots of your deployed app here for your portfolio!

---

Built with ❤️ for learning full-stack development
